/* */ 
module.exports = { "default": require("core-js/library/fn/object/get-own-property-descriptor"), __esModule: true };
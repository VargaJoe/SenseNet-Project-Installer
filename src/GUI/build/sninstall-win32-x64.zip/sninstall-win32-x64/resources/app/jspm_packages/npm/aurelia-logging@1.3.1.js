define(["npm:aurelia-logging@1.3.1/aurelia-logging"], function(main) {
  return main;
});
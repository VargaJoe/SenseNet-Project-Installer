define(["npm:aurelia-binding@1.3.0/aurelia-binding"], function(main) {
  return main;
});
define(["npm:aurelia-path@1.1.1/aurelia-path"], function(main) {
  return main;
});
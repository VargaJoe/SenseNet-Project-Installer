/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/get-prototype-of"), __esModule: true };
define(["npm:aurelia-task-queue@1.2.1/aurelia-task-queue"], function(main) {
  return main;
});
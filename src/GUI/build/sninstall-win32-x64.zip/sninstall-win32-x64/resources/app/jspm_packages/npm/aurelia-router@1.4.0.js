define(["npm:aurelia-router@1.4.0/aurelia-router"], function(main) {
  return main;
});
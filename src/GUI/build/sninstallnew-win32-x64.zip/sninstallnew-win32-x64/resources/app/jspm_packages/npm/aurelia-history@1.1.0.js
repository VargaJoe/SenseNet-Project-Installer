define(["npm:aurelia-history@1.1.0/aurelia-history"], function(main) {
  return main;
});
/* */ 
"use strict";
exports.__esModule = true;
var _promise = require('../core-js/promise');
var _promise2 = _interopRequireDefault(_promise);
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {default: obj};
}
exports.default = function(fn) {
  return function() {
    var gen = fn.apply(this, arguments);
    return new _promise2.default(function(resolve, reject) {
      function step(key, arg) {
        try {
          var info = gen[key](arg);
          var value = info.value;
        } catch (error) {
          reject(error);
          return;
        }
        if (info.done) {
          resolve(value);
        } else {
          return _promise2.default.resolve(value).then(function(value) {
            return step("next", value);
          }, function(err) {
            return step("throw", err);
          });
        }
      }
      return step("next");
    });
  };
};

define(["npm:aurelia-event-aggregator@1.0.1/aurelia-event-aggregator"], function(main) {
  return main;
});
/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/get"), __esModule: true };
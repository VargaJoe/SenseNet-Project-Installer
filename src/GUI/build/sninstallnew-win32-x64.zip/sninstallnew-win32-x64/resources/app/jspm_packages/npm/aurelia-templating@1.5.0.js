define(["npm:aurelia-templating@1.5.0/aurelia-templating"], function(main) {
  return main;
});
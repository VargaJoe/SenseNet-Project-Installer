define(["npm:aurelia-polyfills@1.2.2/aurelia-polyfills"], function(main) {
  return main;
});
define(["npm:aurelia-dependency-injection@1.3.2/aurelia-dependency-injection"], function(main) {
  return main;
});
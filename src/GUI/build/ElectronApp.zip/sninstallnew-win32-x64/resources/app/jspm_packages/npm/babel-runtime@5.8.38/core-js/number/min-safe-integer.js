/* */ 
module.exports = { "default": require("core-js/library/fn/number/min-safe-integer"), __esModule: true };
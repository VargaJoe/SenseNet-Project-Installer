/* */ 
module.exports = { "default": require("core-js/library/fn/reflect/construct"), __esModule: true };
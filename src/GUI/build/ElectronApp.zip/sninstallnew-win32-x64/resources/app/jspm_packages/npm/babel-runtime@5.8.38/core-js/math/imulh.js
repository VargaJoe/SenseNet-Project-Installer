/* */ 
module.exports = { "default": require("core-js/library/fn/math/imulh"), __esModule: true };
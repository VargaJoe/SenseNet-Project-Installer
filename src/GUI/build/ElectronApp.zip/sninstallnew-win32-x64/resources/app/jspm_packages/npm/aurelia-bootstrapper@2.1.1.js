define(["npm:aurelia-bootstrapper@2.1.1/aurelia-bootstrapper"], function(main) {
  return main;
});
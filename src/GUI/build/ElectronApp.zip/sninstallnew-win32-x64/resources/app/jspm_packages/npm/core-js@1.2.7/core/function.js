/* */ 
require('../modules/core.function.part');
module.exports = require('../modules/$.core').Function;

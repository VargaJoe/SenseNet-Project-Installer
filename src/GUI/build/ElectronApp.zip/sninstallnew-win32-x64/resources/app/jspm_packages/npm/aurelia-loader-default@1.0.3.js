define(["npm:aurelia-loader-default@1.0.3/aurelia-loader-default"], function(main) {
  return main;
});
define(["npm:aurelia-metadata@1.0.3/aurelia-metadata"], function(main) {
  return main;
});
/* */ 
"use strict";

exports.__esModule = true;

exports.default = function (strings, raw) {
  strings.raw = raw;
  return strings;
};
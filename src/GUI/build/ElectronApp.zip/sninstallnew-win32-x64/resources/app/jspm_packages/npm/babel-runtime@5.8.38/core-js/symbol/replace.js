/* */ 
module.exports = { "default": require("core-js/library/fn/symbol/replace"), __esModule: true };
define(["npm:aurelia-pal@1.4.0/aurelia-pal"], function(main) {
  return main;
});
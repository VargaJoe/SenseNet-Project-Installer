define(["npm:aurelia-templating-binding@1.4.0/aurelia-templating-binding"], function(main) {
  return main;
});
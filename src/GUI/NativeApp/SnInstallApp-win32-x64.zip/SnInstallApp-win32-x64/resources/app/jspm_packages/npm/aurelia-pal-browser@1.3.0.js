define(["npm:aurelia-pal-browser@1.3.0/aurelia-pal-browser"], function(main) {
  return main;
});
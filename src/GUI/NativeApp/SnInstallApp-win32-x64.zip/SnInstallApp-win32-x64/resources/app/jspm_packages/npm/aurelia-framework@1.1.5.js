define(["npm:aurelia-framework@1.1.5/aurelia-framework"], function(main) {
  return main;
});
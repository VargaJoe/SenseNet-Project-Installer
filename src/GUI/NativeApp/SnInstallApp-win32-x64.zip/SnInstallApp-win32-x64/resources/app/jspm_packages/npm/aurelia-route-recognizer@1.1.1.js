define(["npm:aurelia-route-recognizer@1.1.1/aurelia-route-recognizer"], function(main) {
  return main;
});
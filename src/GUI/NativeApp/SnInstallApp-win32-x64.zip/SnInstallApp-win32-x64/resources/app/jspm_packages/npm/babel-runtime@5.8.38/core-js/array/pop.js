/* */ 
module.exports = { "default": require("core-js/library/fn/array/pop"), __esModule: true };